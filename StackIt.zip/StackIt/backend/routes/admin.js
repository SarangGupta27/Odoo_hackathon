// routes/admin.js
const express = require('express');
const db = require('../db');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

// Only allow admins
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Access denied' });
  next();
}

// Ban user
router.post('/ban/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    await db.execute('UPDATE users SET banned = 1 WHERE id = ?', [req.params.id]);
    res.json({ message: 'User banned successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to ban user', details: err });
  }
});

// Reject question
router.post('/reject/:questionId', authMiddleware, adminOnly, async (req, res) => {
  try {
    await db.execute('UPDATE questions SET status = ? WHERE id = ?', ['rejected', req.params.questionId]);
    res.json({ message: 'Question rejected' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to reject question', details: err });
  }
});

module.exports = router;
