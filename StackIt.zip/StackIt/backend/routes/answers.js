const express = require('express');
const db = require('../db');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

// Vote on answer
router.post('/:id/vote', authMiddleware, async (req, res) => {
  const { vote } = req.body;
  const userId = req.user.userId;
  const answerId = req.params.id;

  try {
    await db.execute(
      `INSERT INTO votes (user_id, answer_id, vote)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE vote = ?`,
      [userId, answerId, vote, vote]
    );
    res.json({ message: 'Vote recorded' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to vote', details: err });
  }
});

// Accept answer
router.post('/:id/accept', authMiddleware, async (req, res) => {
  const answerId = req.params.id;
  const userId = req.user.userId;

  const [[answer]] = await db.execute(
    'SELECT question_id FROM answers WHERE id = ?', [answerId]
  );
  if (!answer) return res.status(404).json({ error: 'Answer not found' });

  const [[question]] = await db.execute(
    'SELECT user_id FROM questions WHERE id = ?', [answer.question_id]
  );
  if (question.user_id !== userId) return res.status(403).json({ error: 'Forbidden' });

  await db.execute('UPDATE answers SET accepted = FALSE WHERE question_id = ?', [answer.question_id]);
  await db.execute('UPDATE answers SET accepted = TRUE WHERE id = ?', [answerId]);

  res.json({ message: 'Answer accepted' });
});

module.exports = router;
