// routes/notifications.js
const express = require('express');
const db = require('../db');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

// Get recent notifications for a user
router.get('/', authMiddleware, async (req, res) => {
  try {
    const [notifications] = await db.execute(
      'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10',
      [req.user.userId]
    );
    res.json(notifications);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load notifications', details: err });
  }
});

module.exports = router;
