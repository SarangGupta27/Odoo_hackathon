// routes/questions.js
const express = require('express');
const db = require('../db');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

// Create a new question
router.post('/', authMiddleware, async (req, res) => {
  const { title, description, tags } = req.body;
  const userId = req.user.userId;

  if (!title || !description || !tags) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const [result] = await db.execute(
      'INSERT INTO questions (user_id, title, description, tags, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
      [userId, title, description, tags, 'pending']
    );

    res.status(201).json({ message: 'Question created successfully', questionId: result.insertId });
  } catch (err) {
    res.status(500).json({ error: 'Failed to post question', details: err });
  }
});

// Get all questions (with vote/answer count)
router.get('/', async (req, res) => {
  const { tag, sort = 'newest', page = 1, limit = 3 } = req.query;
  const offset = (page - 1) * limit;

  let query = `
    SELECT q.*, u.username,
      (SELECT COUNT(*) FROM answers a WHERE a.question_id = q.id) AS answer_count,
      (SELECT IFNULL(SUM(v.vote), 0)
       FROM answers a LEFT JOIN votes v ON a.id = v.answer_id
       WHERE a.question_id = q.id) AS vote_count
    FROM questions q
    JOIN users u ON q.user_id = u.id
  `;

  const conditions = [];
  const params = [];

  if (tag) {
    conditions.push(`q.tags LIKE ?`);
    params.push(`%${tag}%`);
  }

  if (conditions.length) {
    query += ' WHERE ' + conditions.join(' AND ');
  }

  query += sort === 'answers' ? ' ORDER BY answer_count DESC' : ' ORDER BY q.created_at DESC';
  query += ' LIMIT ? OFFSET ?';
  params.push(+limit, +offset);

  try {
    const [questions] = await db.execute(query, params);
    res.json(questions);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch questions', details: err });
  }
});

// Get a single question and its answers
router.get('/:id', async (req, res) => {
  const questionId = req.params.id;

  try {
    const [[question]] = await db.execute(
      'SELECT q.*, u.username FROM questions q JOIN users u ON q.user_id = u.id WHERE q.id = ?',
      [questionId]
    );

    if (!question) {
      return res.status(404).json({ error: 'Question not found' });
    }

    const [answers] = await db.execute(
      `SELECT a.*, u.username,
              COALESCE(SUM(v.vote), 0) as vote_count
       FROM answers a
       LEFT JOIN votes v ON a.id = v.answer_id
       JOIN users u ON a.user_id = u.id
       WHERE a.question_id = ?
       GROUP BY a.id`,
      [questionId]
    );

    res.json({ question, answers });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch question details', details: err });
  }
});

// Post an answer
router.post('/:id/answers', authMiddleware, async (req, res) => {
  const answer = req.body.answer;
  const userId = req.user.userId;
  const questionId = req.params.id;

  if (!answer) {
    return res.status(400).json({ error: 'Answer content is required' });
  }

  try {
    await db.execute(
      'INSERT INTO answers (question_id, user_id, answer, created_at) VALUES (?, ?, ?, NOW())',
      [questionId, userId, answer]
    );
    res.status(201).json({ message: 'Answer posted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to post answer', details: err });
  }
});

module.exports = router;
