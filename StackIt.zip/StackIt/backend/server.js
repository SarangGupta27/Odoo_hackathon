const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');
const questionRoutes = require('./routes/questions');
const adminRoutes = require('./routes/admin');
const notificationRoutes = require('./routes/notifications');
const answerRoutes = require('./routes/answers'); // ✅ make sure this is here

dotenv.config();

const app = express(); // ✅ MUST come before any app.use()

app.use(cors());
app.use(express.json());

// ✅ ROUTES
app.use('/api/auth', authRoutes);
app.use('/api/questions', questionRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/answers', answerRoutes); // ✅ place it here

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
