// script.js

// DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  const askQuestionBtn = document.querySelector('.ask-question-btn');
  const askQuestionModal = document.getElementById('askQuestionModal');
  const closeButton = document.querySelector('.modal .close-button');
  const askQuestionForm = document.getElementById('askQuestionForm');
  const notificationBell = document.querySelector('.notification-bell');
  const notificationDropdown = document.querySelector('.notification-dropdown');

  const loginBtn = document.querySelector('#loginBtn');
  const signupBtn = document.querySelector('#signupBtn');
  const loginForm = document.querySelector('#loginForm');
  const registerForm = document.querySelector('#registerForm');
  const loginModal = document.getElementById('loginModal');
  const registerModal = document.getElementById('registerModal');
  const loginClose = document.querySelector('#loginModal .close-button');
  const registerClose = document.querySelector('#registerModal .close-button');
  const logoutBtn = document.getElementById('logoutBtn');

  const sortSelect = document.getElementById('sortSelect');
  const tagInput = document.getElementById('tagInput');
  const prevBtn = document.getElementById('prevPage');
  const nextBtn = document.getElementById('nextPage');
  const pageLabel = document.getElementById('pageLabel');

  let currentPage = 1;
  const limit = 3;

  // Initialize Quill
  const quill = new Quill('#quillEditor', {
    theme: 'snow',
    placeholder: 'Describe your question in detail...',
    modules: {
      toolbar: [
        ['bold', 'italic', 'strike'],
        [{ list: 'ordered' }, { list: 'bullet' }],
        ['link', 'image'],
        [{ align: [] }],
        ['emoji']
      ]
    }
  });

  // Modal handlers
  askQuestionBtn?.addEventListener('click', () => askQuestionModal.classList.add('show'));
  closeButton?.addEventListener('click', () => askQuestionModal.classList.remove('show'));
  loginBtn?.addEventListener('click', () => loginModal.classList.add('show'));
  signupBtn?.addEventListener('click', () => registerModal.classList.add('show'));
  loginClose?.addEventListener('click', () => loginModal.classList.remove('show'));
  registerClose?.addEventListener('click', () => registerModal.classList.remove('show'));

  window.addEventListener('click', (e) => {
    if (e.target === askQuestionModal) askQuestionModal.classList.remove('show');
    if (e.target === loginModal) loginModal.classList.remove('show');
    if (e.target === registerModal) registerModal.classList.remove('show');
  });

  notificationBell?.addEventListener('click', (e) => {
    e.stopPropagation();
    notificationDropdown.classList.toggle('show');
  });
  document.addEventListener('click', (e) => {
    if (!notificationBell.contains(e.target) && !notificationDropdown.contains(e.target)) {
      notificationDropdown.classList.remove('show');
    }
  });

  async function loadQuestions() {
    const tag = tagInput?.value.trim();
    const sort = sortSelect?.value || 'newest';

    const url = new URL('http://localhost:5000/api/questions');
    if (tag) url.searchParams.set('tag', tag);
    url.searchParams.set('sort', sort);
    url.searchParams.set('page', currentPage);
    url.searchParams.set('limit', limit);

    try {
      const response = await fetch(url);
      const questions = await response.json();
      const questionList = document.querySelector('.question-list');

      const cards = questions.map(q => `
        <div class="question-card">
          <div class="question-stats">
            <div class="stat">
              <span class="count">${q.vote_count || 0}</span>
              <span class="label">votes</span>
            </div>
            <div class="stat">
              <span class="count">${q.answer_count || 0}</span>
              <span class="label">answers</span>
            </div>
          </div>
          <div class="question-summary">
            <h2 class="question-title"><a href="question.html?id=${q.id}">${q.title}</a></h2>
            <div class="question-meta">
              <div class="tags">
                ${q.tags.split(',').map(tag => `<span class="tag">#${tag.trim()}</span>`).join('')}
              </div>
              <div class="author-info">asked by ${q.username}</div>
            </div>
          </div>
        </div>
      `).join('');

      questionList.innerHTML = `<h1>All Questions</h1>${cards}`;
      pageLabel.textContent = `Page ${currentPage}`;
    } catch (err) {
      console.error('Error loading questions:', err);
    }
  }

  sortSelect?.addEventListener('change', () => {
    currentPage = 1;
    loadQuestions();
  });

  tagInput?.addEventListener('input', () => {
    currentPage = 1;
    loadQuestions();
  });

  prevBtn?.addEventListener('click', () => {
    if (currentPage > 1) {
      currentPage--;
      loadQuestions();
    }
  });

  nextBtn?.addEventListener('click', () => {
    currentPage++;
    loadQuestions();
  });

  askQuestionForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    document.getElementById('questionDescription').value = quill.root.innerHTML;
    const title = document.getElementById('questionTitle').value;
    const description = quill.root.innerHTML;
    const tags = document.getElementById('questionTags').value;
    const token = localStorage.getItem('token');
    if (!token) return alert('Please login to ask a question');

    try {
      const res = await fetch('http://localhost:5000/api/questions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ title, description, tags })
      });

      const data = await res.json();
      if (res.ok) {
        alert('Question submitted successfully');
        askQuestionModal.classList.remove('show');
        askQuestionForm.reset();
        quill.setContents([]);
        loadQuestions();
      } else {
        alert(data.error || 'Failed to submit question');
      }
    } catch (err) {
      console.error('Error posting question:', err);
    }
  });

  loginForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    const res = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();
    if (res.ok) {
      localStorage.setItem('token', data.token);
      alert('Login successful');
      loginModal.classList.remove('show');
      location.reload();
    } else {
      alert(data.error || 'Login failed');
    }
  });

  registerForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    const res = await fetch('http://localhost:5000/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password })
    });

    const data = await res.json();
    if (res.ok) {
      alert('Registration successful');
      registerModal.classList.remove('show');
    } else {
      alert(data.error || 'Registration failed');
    }
  });

  logoutBtn?.addEventListener('click', () => {
    localStorage.removeItem('token');
    location.reload();
  });

  const loggedInUserSection = document.querySelector('.logged-in-user');
  const authButtons = document.querySelectorAll('.auth-section .btn-secondary');
  if (localStorage.getItem('token')) {
    loggedInUserSection.style.display = 'flex';
    authButtons.forEach(btn => btn.style.display = 'none');
    logoutBtn.style.display = 'inline-block';
  }

  // Load questions on page load
  loadQuestions();
});
